#include<stdio.h>
#include<stdlib.h>
static char array[81920]={'0'};
int main()
{
	int i,j;
	for(i=0;i<20;i++)
	for(j=0;j<4096;j++)
	{
	array[i*4096+j]='s';			
	}
	while(1);
}	
