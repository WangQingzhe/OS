#define __LIBRARY__
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/types.h>
#include "new.h"

_syscall1(int,swapinfo1,int,num)

void test_swap(void){

    printf("Total Swap Blocks:%d\n",swapinfo1(1));
    printf("Available Swap Blocks:%d\n",swapinfo1(2));
    printf("Swapped in pages:%d\n",swapinfo1(3));
    printf("Swapped out pages:%d\n",swapinfo1(4));
}

int main(void){
    test_swap();
    return 0;
}
